import os

# current directory
local_path = os.path.dirname(__file__)

# default mode for tools. Expect them to be run from a Python toolbox,
# not the command line by default.
mode = 'toolbox'

# debug mode, enables extra logging
debug = False
